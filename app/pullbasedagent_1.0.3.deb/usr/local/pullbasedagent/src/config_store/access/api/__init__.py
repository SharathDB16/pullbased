from libutils.base.log import log

# create namespace specific logger
log = log.getLogger(__name__)
